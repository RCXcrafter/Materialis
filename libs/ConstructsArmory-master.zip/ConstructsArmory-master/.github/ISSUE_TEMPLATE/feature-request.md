---
name: Feature Request
about: Offer a suggestion for a new feature or change
title: ''
labels: enhancement
assignees: TheIllusiveC4

---

**Please describe the new feature or change.**


**Please describe why you want this feature.**
