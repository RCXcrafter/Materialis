package slimeknights.mantle.client.book.data.element;

import net.minecraft.util.ResourceLocation;

public class DataLocation {

  public String file;
  public transient ResourceLocation location;
}
