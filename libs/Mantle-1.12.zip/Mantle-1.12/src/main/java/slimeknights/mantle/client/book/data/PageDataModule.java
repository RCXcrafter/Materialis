package slimeknights.mantle.client.book.data;

public class PageDataModule extends PageData {
    /** Module required to load this section, see {@link slimeknights.mantle.pulsar.control.PulseManager#isPulseLoaded(String)} for more details */
    public String module = "";
}
