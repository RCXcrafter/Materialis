---
name: Bug report
about: Report a bug.
title: ''
labels: bug
assignees: ''

---

**Minecraft Version**


**Mantle Version**


**Versions of Mantle dependant mods**


**Forge version/build**


**Versions of any mods potentially related to the issue**


**If crash, steps to reproduce**


**If crash, ForgeModLoader-client-0.log (the FML log) from the root folder of the client**


Relevant screenshots are greatly appreciated. Thanks for reporting.
