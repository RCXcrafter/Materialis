**Issue description:**

**If crashed, link to crash report (use a site such as pastebin):**

**Versions:**
* Minecraft: 
* Forge: 
* Mantle: 
* Tinkers Construct: 

**Can it be reproduced with *just* Tinkers Construct? If not, list the other mods *required* to reproduce the issue.**
